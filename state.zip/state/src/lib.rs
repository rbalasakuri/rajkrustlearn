pub mod blog {

    pub struct post {
        content :  String,
        state : Option<Box<dyn state>>,
     }
     
     impl post {

        pub fn new() -> post {

           post {

             content : String::new(),
             state :  Some(Box::new(Draft{})),
           }
        }

        pub fn add_text(&mut self, text : &str) {
            
            self.content.push_str(text);
            //self.state.as_ref().unwrap().add_text(self,text)
        }

        pub fn content( &self ) -> &str {
            self.state.as_ref().unwrap().content(self)
        }

        pub fn request_review (&mut self) {

            if let Some(s) = self.state.take() {
                self.state = Some(s.request_review());  
            }    
        }

        pub fn approve (&mut self) {
            if let Some(s) = self.state.take() {
                self.state =  Some(s.approve())
            }
        }
  
        pub fn reject (&mut self) {
            if let Some(s) = self.state.take() {
                self.state =  Some(s.reject())
            }
        }
    
     }


     trait state {

        fn request_review (self : Box<Self>) -> Box<dyn state>;
        fn reject (self : Box<Self>) -> Box<dyn state>;
        fn approve (self : Box<Self>) -> Box<dyn state> ;
        fn content<'a>(&self, post: & 'a post) -> & 'a str { 
              ""
        }
        /*fn add_text<'a>(&self, post:  &'a mut post, text: &str) {
        } */

     }
     
struct Draft{}
impl state for Draft {

         fn request_review (self : Box<Self>) -> Box<dyn state> { 
              Box::new(PendingReview {})
         }

         fn approve (self : Box<Self>) -> Box<dyn state> {
            self
         }

         fn reject (self : Box<Self>) -> Box<dyn state> {
            self
         }


} 

    struct PendingReview {}

    impl state for PendingReview {

            fn request_review (self : Box<Self>) -> Box<dyn state> { 
                 self
            }

            fn approve (self : Box<Self>) -> Box<dyn state> {
                Box::new(Published {})
            }

            fn reject (self : Box<Self>) -> Box<dyn state> {
                Box::new(Draft {})
            }
        }
   
    struct Published {}

    impl state for Published {

        fn content <'a> (&self, post: &'a post ) -> &'a str {
                &post.content()
        }

        fn request_review (self : Box<Self>) -> Box<dyn state> { 
            self
        }
        fn approve (self : Box<Self>) -> Box<dyn state> {
            self
        }

        fn reject (self : Box<Self>) -> Box<dyn state> {
            self
        }

    }
}

